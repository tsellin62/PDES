#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

//enums/structs for car and passengers
typedef enum {
	LOADING,
	RUNNING,
	UNLOADING
} car_state;

typedef struct {
	int id;
	int sequence;
	int passenger_count;
	car_state state;
	int boarded;
	int unboarded;
	int* aboard;
	pthread_mutex_t lock;
	pthread_cond_t board_done;
	pthread_cond_t unboard_done;
} car;

typedef struct {
	int id;
	int board_signal;
	int unboard_signal;
	car* my_car;
	unsigned int seed;
	pthread_mutex_t lock;
	pthread_cond_t can_board;
	pthread_cond_t can_unboard;
} passenger;

typedef struct {
    int time;
    int ticket_queue_size;
    int ride_queue_size;
    int ride_queue_ids[32];
    struct {
        int id;
        car_state state;
        int passenger_count;
        int capacity;
        int aboard[16];
    } car_snapshots[16];
    int num_cars;
} snapshot;

//default options
int n = 10;  //number of passenger threads
int c = 2;   //number of car threads
int p = 2;   //capacity per car
int w = 1;   //car waiting period
int r = 1;   //car ride duration
int t = 30;  //park open duration
int j = 3;   //ride queue max size

//forward declarations
void board_car(passenger* p);
void unboard_car(passenger* p);

//pipe globals
int monitor_pipe[2];
pthread_t monitor_thread;

//passenger/car arrays
car* cars;
passenger* passengers;

//park state
int park_open = 1;
pthread_mutex_t park_mutex;
pthread_cond_t park_closed;

//ticket booth
pthread_mutex_t ticket_booth_mutex;

//ride queue
int ride_queue_size = 0;
int* ride_queue;
int ride_queue_head = 0;
int ride_queue_tail = 0;
pthread_mutex_t ride_queue_mutex;
pthread_cond_t ride_queue_not_full;
pthread_cond_t passenger_ready;

//loading zone (one car loads at a time)
pthread_mutex_t loading_zone_mutex;
pthread_cond_t loading_zone_free;
int loading_zone_occupied = 0;

//unload ordering
int next_unload_seq = 0;
int current_sequence = 0;
pthread_mutex_t unload_order_mutex;
pthread_cond_t my_turn_to_unload;

void init_globals() {
    pthread_mutex_init(&park_mutex, NULL);
	pthread_cond_init(&park_closed, NULL);
    pthread_mutex_init(&ticket_booth_mutex, NULL);
    pthread_mutex_init(&ride_queue_mutex, NULL);
    pthread_cond_init(&ride_queue_not_full, NULL);
	pthread_cond_init(&passenger_ready, NULL);
    pthread_mutex_init(&loading_zone_mutex, NULL);
    pthread_cond_init(&loading_zone_free, NULL);
    pthread_mutex_init(&unload_order_mutex, NULL);
    pthread_cond_init(&my_turn_to_unload, NULL);
	ride_queue = (int*)malloc(j * sizeof(int));
}

void destroy_globals() {
    pthread_mutex_destroy(&park_mutex);
	pthread_cond_destroy(&park_closed);
    pthread_mutex_destroy(&ticket_booth_mutex);
    pthread_mutex_destroy(&ride_queue_mutex);
    pthread_cond_destroy(&ride_queue_not_full);
    pthread_mutex_destroy(&loading_zone_mutex);
    pthread_cond_destroy(&loading_zone_free);
    pthread_mutex_destroy(&unload_order_mutex);
    pthread_cond_destroy(&my_turn_to_unload);
	free(ride_queue);
}

int is_park_open() {
	pthread_mutex_lock(&park_mutex);
	int open = park_open;
	pthread_mutex_unlock(&park_mutex);
	return open;
}

//initialize and clean up passengers and cars
void init_car(car *c, int id) {
    c->id = id;
	c->sequence = 0;
    c->passenger_count = 0;
    c->state = LOADING;
    c->boarded = 0;
    c->unboarded = 0;
	c->aboard = (int*)malloc(p * sizeof(int));
    pthread_mutex_init(&c->lock, NULL);
    pthread_cond_init(&c->board_done, NULL);
    pthread_cond_init(&c->unboard_done, NULL);
}

void init_passenger(passenger *p, int id) {
	p->id = id;
    p->board_signal = 0;
    p->unboard_signal = 0;
	p->seed = (unsigned int)(time(NULL) ^ (id * 12345));
	p->my_car = NULL;
    pthread_mutex_init(&p->lock, NULL);
    pthread_cond_init(&p->can_board, NULL);
    pthread_cond_init(&p->can_unboard, NULL);
}

void clean_car(car *c) {
	free(c->aboard);
    pthread_mutex_destroy(&c->lock);
    pthread_cond_destroy(&c->board_done);
    pthread_cond_destroy(&c->unboard_done);
}

void clean_passenger(passenger *p) {
    pthread_mutex_destroy(&p->lock);
    pthread_cond_destroy(&p->can_board);
    pthread_cond_destroy(&p->can_unboard);
}

//close park
void close_park() {
	//set park closed
	pthread_mutex_lock(&park_mutex);
	park_open = 0;
	pthread_cond_broadcast(&park_closed);
	pthread_mutex_unlock(&park_mutex);

	//wake all threads blocked on any condition variable
	pthread_mutex_lock(&ride_queue_mutex);
	pthread_cond_broadcast(&passenger_ready);
	pthread_cond_broadcast(&ride_queue_not_full);
	pthread_mutex_unlock(&ride_queue_mutex);

	pthread_mutex_lock(&ticket_booth_mutex);
	pthread_cond_broadcast(&ride_queue_not_full);
	pthread_mutex_unlock(&ticket_booth_mutex);

	pthread_mutex_lock(&loading_zone_mutex);
	pthread_cond_broadcast(&loading_zone_free);
	pthread_mutex_unlock(&loading_zone_mutex);

	pthread_mutex_lock(&unload_order_mutex);
	pthread_cond_broadcast(&my_turn_to_unload);
	pthread_mutex_unlock(&unload_order_mutex);

	for (int i = 0; i < n; i++) {
		pthread_mutex_lock(&passengers[i].lock);
		pthread_cond_broadcast(&passengers[i].can_board);
		pthread_cond_broadcast(&passengers[i].can_unboard);
		pthread_mutex_unlock(&passengers[i].lock);
	}

	for (int i = 0; i < c; i++) {
		pthread_mutex_lock(&cars[i].lock);
		pthread_cond_broadcast(&cars[i].board_done);
		pthread_cond_broadcast(&cars[i].unboard_done);
		pthread_mutex_unlock(&cars[i].lock);
	}
}

//other functions
int get_time() {
	static time_t start = 0;
	if (start == 0) {
		start = time(NULL);
	}
	return (int)(time(NULL) - start);
}


void enqueue(int passenger_id) {
	ride_queue[ride_queue_tail] = passenger_id;
	ride_queue_tail = (ride_queue_tail + 1) % j;
	ride_queue_size++;
}

int dequeue() {
	int id = ride_queue[ride_queue_head];
	ride_queue_head = (ride_queue_head + 1) % j;
	ride_queue_size--;
	return id;
}

//passenger functions
void explore_park(passenger* p) {
	printf("[Time: %d] Passenger %d is exploring the park\n", get_time(), p->id);
	int explore_time = (rand_r(&p->seed) % 10) + 1;

	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_sec += explore_time;

	pthread_mutex_lock(&park_mutex);
	while (park_open) {
		int result = pthread_cond_timedwait(&park_closed, &park_mutex, &ts);
		if (result == ETIMEDOUT) {
			break;
		}
	}
	pthread_mutex_unlock(&park_mutex);
}

int get_ride_ticket(passenger* p) {
	pthread_mutex_lock(&ticket_booth_mutex);
	printf("[Time: %d] Passenger %d entered the ticket queue\n", get_time(), p->id);

	//if ride is full, wait
	//pthread_mutex_lock(&ticket_booth_mutex);
	while (ride_queue_size >= j && is_park_open()) {
		pthread_cond_wait(&ride_queue_not_full, &ticket_booth_mutex);
	}

	//if park closes while waiting, exit
	if (!is_park_open()) {
		pthread_mutex_unlock(&ticket_booth_mutex);
		return 0;
	}
	
	printf("[Time: %d] Passenger %d acquired a ticket\n", get_time(), p->id);
	pthread_mutex_unlock(&ticket_booth_mutex);
	return 1;
}

int enter_ride_queue(passenger* p) {
	printf("[Time: %d] Passenger %d has entered the ride queue\n", get_time(), p->id);
	pthread_mutex_lock(&ride_queue_mutex);
	enqueue(p->id);
	pthread_cond_signal(&passenger_ready);
	pthread_mutex_unlock(&ride_queue_mutex);

	pthread_mutex_lock(&p->lock);
	while (!p->board_signal && is_park_open()) {
		pthread_cond_wait(&p->can_board, &p->lock);
	}
	if (!p->board_signal) {
		pthread_mutex_unlock(&p->lock);
		if (p->my_car != NULL) {
			board_car(p);
			unboard_car(p);
		}
		return 0;
	}

	p->board_signal = 0;
	pthread_mutex_unlock(&p->lock);
	printf("[Time: %d] Passenger %d is boarding\n", get_time(), p->id);
	return 1;
}

void board_car(passenger *p) {
    pthread_mutex_lock(&p->my_car->lock);
    p->my_car->boarded++;

    pthread_cond_signal(&p->my_car->board_done);
    pthread_mutex_unlock(&p->my_car->lock);
}

void unboard_car(passenger *p) {
    pthread_mutex_lock(&p->lock);

    while (!p->unboard_signal && is_park_open()) {
        pthread_cond_wait(&p->can_unboard, &p->lock);
    }

	if (!p->unboard_signal) {
		pthread_mutex_unlock(&p->lock);
		pthread_mutex_lock(&p->my_car->lock);
		p->my_car->unboarded++;
		pthread_cond_signal(&p->my_car->unboard_done);
		pthread_mutex_unlock(&p->my_car->lock);
		p->my_car = NULL;
		return;
	}

	//reset for next ride
    p->unboard_signal = 0;
    pthread_mutex_unlock(&p->lock);

    //tell the car this passenger has unboarded
    pthread_mutex_lock(&p->my_car->lock);
    p->my_car->unboarded++;
    printf("[Time: %d] Passenger %d unboarded\n", get_time(), p->id);
    pthread_cond_signal(&p->my_car->unboard_done);
    pthread_mutex_unlock(&p->my_car->lock);

    //decrement ride queue and signal ticket booth
    pthread_mutex_lock(&ticket_booth_mutex);
    pthread_cond_signal(&ride_queue_not_full);
    pthread_mutex_unlock(&ticket_booth_mutex);

	//detach from car
    p->my_car = NULL;
}

//car functions
void load(car *c) {
	printf("[Time: %d] Car %d invoked load()\n", get_time(), c->id);
    //get loading zone
    pthread_mutex_lock(&loading_zone_mutex);
    while (loading_zone_occupied && is_park_open()) {
        pthread_cond_wait(&loading_zone_free, &loading_zone_mutex);
    }
	if (!is_park_open()) {
		pthread_mutex_unlock(&loading_zone_mutex);
		return;
	}
	//printf("Car %d acquired loading zone\n", c->id);
    loading_zone_occupied = 1;
    pthread_mutex_unlock(&loading_zone_mutex);

    pthread_mutex_lock(&c->lock);
    c->state = LOADING;
    c->boarded = 0;
    c->passenger_count = 0;
    pthread_mutex_unlock(&c->lock);

    //wait until at least one passenger is in the queue
    pthread_mutex_lock(&ride_queue_mutex);
    while (ride_queue_size == 0) {
        pthread_cond_wait(&passenger_ready, &ride_queue_mutex);
		if (!is_park_open()) {
			pthread_mutex_unlock(&ride_queue_mutex);
			pthread_mutex_lock(&loading_zone_mutex);
			loading_zone_occupied = 0;
			pthread_cond_signal(&loading_zone_free);
			pthread_mutex_unlock(&loading_zone_mutex);
			return;
		}
    }

    //signal first passenger to board
    int pid = dequeue();
    pthread_mutex_unlock(&ride_queue_mutex);

    passenger *first = &passengers[pid];
    first->my_car = c;
	c->aboard[c->boarded] = first->id;
    pthread_mutex_lock(&first->lock);
    first->board_signal = 1;
    pthread_cond_signal(&first->can_board);
    pthread_mutex_unlock(&first->lock);

	//get necessary time for wait
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_sec += w;

    //wait for boarding, keep loading until full or timeout
    pthread_mutex_lock(&c->lock);
    while (c->boarded < p && is_park_open()) {
        int result = pthread_cond_timedwait(&c->board_done, &c->lock, &ts);

        if (result == ETIMEDOUT) {
            if (c->boarded > 0) {
				printf("[Time: %d] Car %d waiting period expired\n", get_time(), c->id);
                break;
            }
			else if (!is_park_open()) {
				pthread_mutex_unlock(&c->lock);
				return;
			}
        } 
		else {
            //a passenger boarded, signal next if queue has more
            pthread_mutex_lock(&ride_queue_mutex);
            if (ride_queue_size > 0 && c->boarded < p) {
                int next_pid = dequeue();
                pthread_mutex_unlock(&ride_queue_mutex);

                passenger *next = &passengers[next_pid];
                next->my_car = c;
				c->aboard[c->boarded] = next->id;
                pthread_mutex_lock(&next->lock);
                next->board_signal = 1;
                pthread_cond_signal(&next->can_board);
                pthread_mutex_unlock(&next->lock);
            } 
			else {
                pthread_mutex_unlock(&ride_queue_mutex);
            }
        }
    }

	if (!is_park_open() && c->boarded == 0) {
		pthread_mutex_unlock(&c->lock);
		pthread_mutex_lock(&loading_zone_mutex);
		loading_zone_occupied = 0;
		pthread_cond_signal(&loading_zone_free);
		pthread_mutex_unlock(&loading_zone_mutex);
		return;
	}

    c->passenger_count = c->boarded;
	if (c->passenger_count == p) {
		printf("[Time: %d] Car %d is full with %d passengers\n", get_time(), c->id, c->passenger_count);
	}
	
	pthread_mutex_lock(&unload_order_mutex);
	c->sequence = current_sequence++;
	pthread_mutex_unlock(&unload_order_mutex);

    printf("[Time: %d] Car %d has departed to ride\n", get_time(), c->id);
    pthread_mutex_unlock(&c->lock);
	
	pthread_mutex_lock(&loading_zone_mutex);
	loading_zone_occupied = 0;
	pthread_cond_signal(&loading_zone_free);
	pthread_mutex_unlock(&loading_zone_mutex);
	
}

void run(car* c) {
	pthread_mutex_lock(&c->lock);
	c->state = RUNNING;
	pthread_mutex_unlock(&c->lock);
	sleep(r);
	printf("[Time: %d] Car %d has returned from the ride\n", get_time(), c->id);
}

void unload(car* c) {
	//printf("[Debug] Car %d entering unload, sequence=%d, next=%d\n", c->id, c->sequence, next_unload_seq);

	//wait for turn
	pthread_mutex_lock(&unload_order_mutex);
	//printf("[Debug] Car %d got unload_order_mutex\n", c->id);
	while (c->sequence != next_unload_seq && is_park_open()) {
		pthread_cond_wait(&my_turn_to_unload, &unload_order_mutex);
	}
	if (c->sequence != next_unload_seq && is_park_open()) {
		pthread_cond_wait(&my_turn_to_unload, &unload_order_mutex);
	}
	if (!is_park_open()) {
		pthread_mutex_unlock(&unload_order_mutex);
		return;
	}

	pthread_mutex_unlock(&unload_order_mutex);
	//printf("[Debug] Car %d passed sequence check\n", c->id);
	//printf("[Debug] Car %d trying to lock c->lock\n", c->id);

	pthread_mutex_lock(&c->lock);
	//printf("[Debug] Car %d got c->lock\n", c->id);
	c->state = UNLOADING;
	c->unboarded = 0;
	printf("[Time: %d] Car %d has invoked unload()\n", get_time(), c->id);

	//signal each passenger to unboard
	for (int i = 0; i < c->passenger_count; i++) {
		passenger* p = &passengers[c->aboard[i]];
		pthread_mutex_lock(&p->lock);
		p->unboard_signal = 1;
		pthread_cond_signal(&p->can_unboard);
		pthread_mutex_unlock(&p->lock);
	}

	//wait until unboarding complete
	while (c->unboarded < c->passenger_count) {
		pthread_cond_wait(&c->unboard_done, &c->lock);
	}
	pthread_mutex_unlock(&c->lock);

	pthread_mutex_lock(&unload_order_mutex);
	/*printf("[Debug] Car %d waiting for %d/%d unboarded\n",
    c->id, c->unboarded, c->passenger_count);*/
	next_unload_seq++;
	pthread_cond_broadcast(&my_turn_to_unload);
	pthread_mutex_unlock(&unload_order_mutex);

	/*
	//release loading zone
	pthread_mutex_lock(&loading_zone_mutex);
	loading_zone_occupied = 0;
	pthread_cond_signal(&loading_zone_free);
	pthread_mutex_unlock(&loading_zone_mutex);
	*/
}

//thread functions
void* passenger_thread(void* arg) {
	passenger* p = (passenger*)arg;
	printf("[Time: %d] Passenger %d entered the park\n", get_time(), p->id);

	while (is_park_open()) {
		explore_park(p);
		if (!is_park_open()) {
			continue;
		}
		printf("[Time: %d] Passenger %d finished exploring, entering the ticket booth\n", get_time(), p->id);
		if(!get_ride_ticket(p)) {
			continue;
		}
		if (!enter_ride_queue(p)) {
			continue;
		}
		board_car(p);
		unboard_car(p);
	}	

	//printf("[Debug] Passenger %d exiting thread\n", p->id);
	return NULL;
}

void* car_thread(void* arg) {
	car* c = (car*)arg;

	while(is_park_open()) {
		load(c);
		if (c->passenger_count == 0) {
			break;
		}
		run(c);
		unload(c);
	}

	//printf("[Debug] Car %d exiting thread\n", c->id);
	return NULL;
}

void* monitor_thread_func(void* arg) {
	(void)arg;
    while (is_park_open()) {
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 5;

        pthread_mutex_lock(&park_mutex);
        while (park_open) {
            int result = pthread_cond_timedwait(&park_closed, &park_mutex, &ts);
            if (result == ETIMEDOUT) break;
        }
        pthread_mutex_unlock(&park_mutex);

        if (!is_park_open()) break;

        snapshot s;
		memset(&s, 0, sizeof(snapshot));
        s.time = get_time();
        s.num_cars = c;

        //get ride queue
        pthread_mutex_lock(&ride_queue_mutex);
        s.ride_queue_size = ride_queue_size;
        for (int i = 0; i < ride_queue_size; i++) {
            s.ride_queue_ids[i] = ride_queue[(ride_queue_head + i) % j];
        }
        pthread_mutex_unlock(&ride_queue_mutex);
        s.ticket_queue_size = s.ride_queue_size;

        //get car states
        for (int i = 0; i < c; i++) {
            pthread_mutex_lock(&cars[i].lock);
            s.car_snapshots[i].id = cars[i].id;
            s.car_snapshots[i].state = cars[i].state;
            s.car_snapshots[i].passenger_count = cars[i].passenger_count;
            s.car_snapshots[i].capacity = p;
            for (int k = 0; k < cars[i].passenger_count; k++) {
                s.car_snapshots[i].aboard[k] = cars[i].aboard[k];
            }
            pthread_mutex_unlock(&cars[i].lock);
        }

        write(monitor_pipe[1], &s, sizeof(snapshot));
    }

    close(monitor_pipe[1]);
    return NULL;
}

void run_monitor_child(pthread_t* car_threads, pthread_t* passenger_threads) {
	free(cars);
	free(passengers);
	free(car_threads);
	free(passenger_threads);
	free(ride_queue);

    close(monitor_pipe[1]);

    snapshot s;
    while (read(monitor_pipe[0], &s, sizeof(snapshot)) == sizeof(snapshot)) {
        /*printf("\n========== [Monitor @ Time %d] ==========\n", s.time);

        printf("Ticket queue:  %d waiting\n", s.ticket_queue_size);

        printf("Ride queue:    %d waiting [ ", s.ride_queue_size);
        for (int i = 0; i < s.ride_queue_size; i++) {
            printf("P%d ", s.ride_queue_ids[i]);
        }
        printf("]\n");

        for (int i = 0; i < s.num_cars; i++) {
            const char* state_str =
                s.car_snapshots[i].state == LOADING   ? "LOADING" :
                s.car_snapshots[i].state == RUNNING   ? "RUNNING" :
                s.car_snapshots[i].state == UNLOADING ? "UNLOADING" : "UNKNOWN";

            printf("Car %d: [%s] %d/%d passengers [ ",
                s.car_snapshots[i].id,
                state_str,
                s.car_snapshots[i].passenger_count,
                s.car_snapshots[i].capacity);

            for (int k = 0; k < s.car_snapshots[i].passenger_count; k++) {
                printf("P%d ", s.car_snapshots[i].aboard[k]);
            }
            printf("]\n");
        }
        printf("==========================================\n\n");
		*/
		char buf[2048];
		int pos = 0;

		pos += snprintf(buf + pos, sizeof(buf) - pos, "\n========== [Monitor @ Time %d] ==========\n", s.time);
		pos += snprintf(buf + pos, sizeof(buf) - pos, "Ticket queue:  %d waiting\n", s.ticket_queue_size);
		pos += snprintf(buf + pos, sizeof(buf) - pos, "Ride queue:    %d waiting [ ", s.ride_queue_size);
		for (int i = 0; i < s.ride_queue_size; i++)
			pos += snprintf(buf + pos, sizeof(buf) - pos, "P%d ", s.ride_queue_ids[i]);
		pos += snprintf(buf + pos, sizeof(buf) - pos, "]\n");

		for (int i = 0; i < s.num_cars; i++) {
			const char* state_str =
				s.car_snapshots[i].state == LOADING   ? "LOADING"   :
				s.car_snapshots[i].state == RUNNING   ? "RUNNING"   :
				s.car_snapshots[i].state == UNLOADING ? "UNLOADING" : "UNKNOWN";
			pos += snprintf(buf + pos, sizeof(buf) - pos, "Car %d: [%s] %d/%d passengers [ ",
				s.car_snapshots[i].id, state_str,
				s.car_snapshots[i].passenger_count,
				s.car_snapshots[i].capacity);
			for (int k = 0; k < s.car_snapshots[i].passenger_count; k++)
				pos += snprintf(buf + pos, sizeof(buf) - pos, "P%d ", s.car_snapshots[i].aboard[k]);
			pos += snprintf(buf + pos, sizeof(buf) - pos, "]\n");
		}
		pos += snprintf(buf + pos, sizeof(buf) - pos, "==========================================\n\n");

		printf("%s", buf);
		fflush(stdout);
    }

    close(monitor_pipe[0]);
    exit(0);
}

//main
int main(int argc, char* argv[]) {	
	//parse flags
	for (int i = 1; i < argc;) {
		if (strcmp(argv[i], "-n") == 0) {
			n = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-c") == 0) {
			c = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-p") == 0) {
			p = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-w") == 0) {
			w = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-r") == 0) {
			r = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-t") == 0) {
			t = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-j") == 0) {
			j = atoi(argv[i + 1]);
			i += 2;
			continue;
		}
		else if (strcmp(argv[i], "-h") == 0) {
			printf("Usage: ./park [OPTIONS]\n");
			return 0;
		}
		else {
			printf("Error with flags, try again with correct usage\n");
			return 0;
		}

	}

	//printf("n: %d, c: %d, p: %d, w: %d, r: %d, t: %d, j: %d\n", n, c, p, w, r, t, j);

	init_globals();

	cars = (car*)malloc(c * sizeof(car));
	passengers = (passenger*)malloc(n * sizeof(passenger));
	pthread_t* car_threads = (pthread_t*)malloc(c * sizeof(pthread_t));
	pthread_t* passenger_threads = (pthread_t*)malloc(n * sizeof(pthread_t));

	if (pipe(monitor_pipe) == -1) {
		perror("pipe");
		return 1;
	}

	pid_t monitor_pid = fork();
	if (monitor_pid == -1) {
		perror("fork");
		return 1;
	}
	if (monitor_pid == 0) {
		run_monitor_child(car_threads, passenger_threads);
	}

	//parent continues, close read end
	close(monitor_pipe[0]);

	for (int i = 0; i < n; i++) {
		init_passenger(&passengers[i], i);
	}
	for (int i = 0; i < c; i++) {
		init_car(&cars[i], i);
	}
	
	for (int i = 0; i < n; i++) {
		pthread_create(&passenger_threads[i], NULL, passenger_thread, &passengers[i]);
	}
	for (int i = 0; i < c; i++) {
		pthread_create(&car_threads[i], NULL, car_thread, &cars[i]);
	}

	pthread_create(&monitor_thread, NULL, monitor_thread_func, NULL);

	//run park for t
	sleep(t);

	//close park
	close_park();

	//wait for threads to finish
	for (int i = 0; i < n; i++) {
		//printf("[DEBUG] Joining passenger %d\n", i);
		pthread_join(passenger_threads[i], NULL);
		//printf("[DEBUG] Joined passenger %d\n", i);
	}
	for (int i = 0; i < c; i++) {
		//printf("[DEBUG] Joining car %d\n", i);
		pthread_join(car_threads[i], NULL);
		//printf("[DEBUG] Joined car %d\n", i);
	}

	for (int i = 0; i < c; i++) {
		clean_car(&cars[i]);
	}
	for (int i = 0; i < n; i++) {
		clean_passenger(&passengers[i]);
	}

	pthread_join(monitor_thread, NULL);
	waitpid(monitor_pid, NULL, 0);

	destroy_globals();
	free(cars);
	free(passengers);
	free(car_threads);
	free(passenger_threads);
	
	return 0;
}
